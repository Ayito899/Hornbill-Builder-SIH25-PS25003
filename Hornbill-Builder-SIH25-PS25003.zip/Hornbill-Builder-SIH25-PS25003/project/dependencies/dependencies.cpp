// Library includes
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <Wire.h>

// ThingSpeak - will be auto-downloaded by PlatformIO
// For Arduino IDE: Install via Library Manager
#include <ThingSpeak.h>

// Project headers
#include "config.h"
#include "sensors.h"
#include "wifi_manager.h"